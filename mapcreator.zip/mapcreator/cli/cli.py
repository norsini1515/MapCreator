# mapcreator/cli/cli.py
from .__main__ import app

def main():
    app()