# configs/world1.yml
# image: C:/Users/nicho/Documents/World Building/MapCreator/data/raw/landamass_drawing_base.jpg
# image: C:/Users/nicho/Documents/World Building/MapCreator/data/raw/landamass_drawing_base_contrast.jpg
# image: C:/Users/nicho/Documents/World Building/MapCreator/data/processed/test_data/test_centerline_outline2.png
# image: C:/Users/nicho/Documents/World Building/MapCreator/data/processed/test_data/test_centerline_outline_filled.png
# image: C:/Users/nicho/Documents/World Building/MapCreator/data/raw/baselandmass_10282025.jpg
image: C:/Users/nicho/Documents/World Building/MapCreator/data/raw/baseland_12182025_1.jpg
raster_class_config_path: C:/Users/nicho/Documents/World Building/MapCreator/config/raster_classifications.yml
out_dir: C:/Users/nicho/Documents/World Building/MapCreator/data/processed
xmin: 0
ymin: 0
xmax: 3800
ymax: 3800
crs: EPSG:3857
# invert: false
# flood_fill: false
# contrast: 2.0
min_area: 5.0
min_points: 3
log_file_name: "extract_all_{now:%Y-%m-%d_%H-%M-%S}.log"
verbose: True
