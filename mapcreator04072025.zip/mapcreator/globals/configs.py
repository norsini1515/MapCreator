
#WORLD CONFIGURATION
#------------------
WORLD_NAME = 'Htrae'
#------------------

#------------------
#POLYGON GENERATION
#------------------
MIN_AREA = 5
MIN_POINTS = 4