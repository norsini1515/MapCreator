from mapcreator.globals import configs
from mapcreator.globals import directories
