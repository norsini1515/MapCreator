# -*- coding: utf-8 -*-
"""
Created on Sun Apr  6 00:08:16 2025

@author: nichorsin598
"""
import cv2
import numpy as np
from pathlib import Path

def fill_water_regions_to_array(img_path: Path) -> np.ndarray:
    """
    Converts a landmask image (white land, black water) into a filled landmass array.
    Useful for contour extraction of the full base landmass.

    Args:
        img_path: Path to the original 'LakesOPEN' binary image.

    Returns:
        Numpy array of the filled landmass image (binary: 0 for background, 255 for land)
    """
    img = cv2.imread(str(img_path), cv2.IMREAD_GRAYSCALE)

    # Ensure the image is binary (in case of compression artifacts)
    _, binary = cv2.threshold(img, 127, 255, cv2.THRESH_BINARY)

    # Invert: water becomes white (255), land black (0)
    inverted = cv2.bitwise_not(binary)

    # Flood fill background from top-left corner (assumed sea)
    h, w = inverted.shape
    mask = np.zeros((h + 2, w + 2), np.uint8)
    cv2.floodFill(inverted, mask, (0, 0), 0)  # Fill sea with black (0)

    # Invert back: land is white, lakes/seas filled in
    filled = cv2.bitwise_not(inverted)

    return filled

def flood_fill_ocean(img_array: np.ndarray) -> np.ndarray:
    """
    Removes the ocean from a binary water image by flood-filling from the edge.

    Returns a new array where only inland lakes/seas are white (255),
    and ocean (connected to edge) is black (0).
    """
    filled = img_array.copy()
    h, w = filled.shape
    mask = np.zeros((h + 2, w + 2), np.uint8)

    # Fill from top-left (or any edge pixel known to be ocean)
    cv2.floodFill(filled, mask, seedPoint=(0, 0), newVal=0)

    return filled